<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* beam/search.html */
class __TwigTemplate_e01c43dd89d66072d0bd5befc53dc3d0f0ef924bd77304b481309489d297af25 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "beam/search.html"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "beam/search.html"));

        $this->parent = $this->loadTemplate("base.html", "beam/search.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["slug"]) || array_key_exists("slug", $context) ? $context["slug"] : (function () { throw new RuntimeError('Variable "slug" does not exist.', 3, $this->source); })()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "\t\t<div class=\"searchResultsBlock1\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"headerSearchResults\"><img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("asset/other/images/svg/lense.svg"), "html", null, true);
        echo "\"><span>Поиск\t</span></div>
\t\t\t\t<hr class=\"hrSearch\">
\t\t\t\t<div class=\"blockSearchInfo\">
\t\t\t\t\t<div class=\"finded\"><span>Найдено: ";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["find"]) || array_key_exists("find", $context) ? $context["find"] : (function () { throw new RuntimeError('Variable "find" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "</span></div>
\t\t\t\t\t\t\t\t
\t\t\t\t\t<div id=\"searchFormPg\" class=\"searchFormPgSearchHeader\">
\t\t\t\t\t\t<input type=\"text\" name=\"searchSite\" id=\"searchSite\" required=\"\" placeholder=\"Поиск по сайту\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["slug"]) || array_key_exists("slug", $context) ? $context["slug"] : (function () { throw new RuntimeError('Variable "slug" does not exist.', 14, $this->source); })()), "html", null, true);
        echo "\">
\t\t\t\t\t\t<button type=\"submit\" name=\"submitSearchSite\" id=\"submitSearchSite\"><img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("asset/other/images/svg/justSearch.svg"), "html", null, true);
        echo "\"></button>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t<hr class=\"hrSearch\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"sqlB\" style=\"display: none;\">";
        // line 22
        echo twig_escape_filter($this->env, (isset($context["sql"]) || array_key_exists("sql", $context) ? $context["sql"] : (function () { throw new RuntimeError('Variable "sql" does not exist.', 22, $this->source); })()), "html", null, true);
        echo "</div>
\t\t<div class=\"block3IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"contentBlock3IndexPage\">
\t\t\t\t\t<div class=\"forfor\"></div>
\t\t\t\t\t
\t
\t\t\t\t<div class=\"pagination\">
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"ads\">
\t\t\t\t\t<div class=\"headerAds\">Реклама</div>
\t\t\t\t\t<div class=\"mostAds\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 43
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 44
        echo "\t<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("asset/other/js/searchEngine.js"), "html", null, true);
        echo "\" async></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "beam/search.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 44,  149 => 43,  119 => 22,  109 => 15,  105 => 14,  99 => 11,  93 => 8,  89 => 6,  79 => 5,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html' %}

{% block title %}{{slug}}{% endblock %}

{% block content %}
\t\t<div class=\"searchResultsBlock1\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"headerSearchResults\"><img src=\"{{ asset('asset/other/images/svg/lense.svg') }}\"><span>Поиск\t</span></div>
\t\t\t\t<hr class=\"hrSearch\">
\t\t\t\t<div class=\"blockSearchInfo\">
\t\t\t\t\t<div class=\"finded\"><span>Найдено: {{find}}</span></div>
\t\t\t\t\t\t\t\t
\t\t\t\t\t<div id=\"searchFormPg\" class=\"searchFormPgSearchHeader\">
\t\t\t\t\t\t<input type=\"text\" name=\"searchSite\" id=\"searchSite\" required=\"\" placeholder=\"Поиск по сайту\" value=\"{{slug}}\">
\t\t\t\t\t\t<button type=\"submit\" name=\"submitSearchSite\" id=\"submitSearchSite\"><img src=\"{{ asset('asset/other/images/svg/justSearch.svg') }}\"></button>
\t\t\t\t\t</div>
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t<hr class=\"hrSearch\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"sqlB\" style=\"display: none;\">{{sql}}</div>
\t\t<div class=\"block3IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"contentBlock3IndexPage\">
\t\t\t\t\t<div class=\"forfor\"></div>
\t\t\t\t\t
\t
\t\t\t\t<div class=\"pagination\">
\t\t\t\t
\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"ads\">
\t\t\t\t\t<div class=\"headerAds\">Реклама</div>
\t\t\t\t\t<div class=\"mostAds\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>


{% endblock %}

{% block javascript %}
\t<script type=\"text/javascript\" src=\"{{ asset('asset/other/js/searchEngine.js') }}\" async></script>
{% endblock %}", "beam/search.html", "/home/danilkaschoolnikprogrammist/php/beammods.ru/templates/beam/search.html");
    }
}
