const codeWindow = document.querySelector('.pageText');

function showCode() {
	codeWindow.style.transform = 'translateY(0)';
}