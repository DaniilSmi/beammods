<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/search' => [[['_route' => 'search', '_controller' => 'App\\Controller\\SearchController::getInfo'], null, null, null, false, false, null]],
        '/pagi' => [[['_route' => 'paginition', '_controller' => 'App\\Controller\\PaginationController:getInfoPagi'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'register', '_controller' => 'App\\Controller\\RegisterPageController::getPage'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'login', '_controller' => 'App\\Controller\\LoginFormController::getData'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'logout', '_controller' => 'App\\Controller\\LogoutController::logout'], null, null, null, false, false, null]],
        '/profile' => [[['_route' => 'profile', '_controller' => 'App\\Controller\\ProfileController::getProfilePage'], null, null, null, false, false, null]],
        '/fileUpload' => [[['_route' => 'fileUpload', '_controller' => 'App\\Controller\\UploadController::uploadFile'], null, null, null, false, false, null]],
        '/resetPassword' => [[['_route' => 'resetpassword', '_controller' => 'App\\Controller\\ResetController::getResetPage'], null, null, null, false, false, null]],
        '/resetPassword2' => [[['_route' => 'resetPage2', '_controller' => 'App\\Controller\\ResetPage2Controller::getResetPage'], null, null, null, false, false, null]],
        '/sql' => [[['_route' => 'DoSql', '_controller' => 'App\\Controller\\PostUrlController::getInfo'], null, null, null, false, false, null]],
        '/getComments' => [[['_route' => 'getComments', '_controller' => 'App\\Controller\\CommentsGetController::getComment'], null, null, null, false, false, null]],
        '/searchMod' => [[['_route' => 'SearchMod', '_controller' => 'App\\Controller\\SearchModController::search'], null, null, null, false, false, null]],
        '/getPagiSql' => [[['_route' => 'getCBSql', '_controller' => 'App\\Controller\\GetPagiSqlController::getInfo'], null, null, null, false, false, null]],
        '/newThemeForum' => [[['_route' => 'newTheme', '_controller' => 'App\\Controller\\NewThemeForumController::make'], null, null, null, false, false, null]],
        '/aboutus' => [[['_route' => 'aboutUs', '_controller' => 'App\\Controller\\AboutusController::show'], null, null, null, false, false, null]],
        '/creator' => [[['_route' => 'creator', '_controller' => 'App\\Controller\\CreatorController::show'], null, null, null, false, false, null]],
        '/contacts' => [[['_route' => 'contacts', '_controller' => 'App\\Controller\\ContactsController::show'], null, null, null, false, false, null]],
        '/howtouploadmod' => [[['_route' => 'howToLoad', '_controller' => 'App\\Controller\\HowloadController::show'], null, null, null, false, false, null]],
        '/setup' => [[['_route' => 'setup', '_controller' => 'App\\Controller\\SetupController::show'], null, null, null, false, false, null]],
        '/getM' => [[['_route' => 'getM', '_controller' => 'App\\Controller\\ModCController::getInfo'], null, null, null, false, false, null]],
        '/addmod' => [[['_route' => 'showAddMod', '_controller' => 'App\\Controller\\AddmodController::show'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/admin(?'
                    .'|(?:/([^/]++)(?:/([^/]++))?)?(*:206)'
                    .'|(*:214)'
                .')'
                .'|/downloadMod(?'
                    .'|(?:/([^/]++))?(*:252)'
                    .'|(*:260)'
                .')'
                .'|/forum(?'
                    .'|(?:/([^/]++)(?:/([^/]++))?)?(*:306)'
                    .'|(*:314)'
                .')'
                .'|/mod(?'
                    .'|(?:/([^/]++))?(*:344)'
                    .'|(*:352)'
                .')'
                .'|/searchMod/q(?:/([^/]++))?(*:387)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        206 => [[['_route' => 'admin_show', 'slug' => null, 'slave' => null, '_controller' => 'App\\Controller\\AdminController::show'], ['slug', 'slave'], null, null, false, true, null]],
        214 => [[['_route' => 'admin', '_controller' => 'App\\Controller\\AdminController::show'], [], null, null, false, false, null]],
        252 => [[['_route' => 'dw_show', 'slug' => null, '_controller' => 'App\\Controller\\DownloadController::download'], ['slug'], null, null, false, true, null]],
        260 => [[['_route' => 'downloadMod', '_controller' => 'App\\Controller\\DownloadController::download'], [], null, null, false, false, null]],
        306 => [[['_route' => 'forum_show', 'slug' => null, 'page' => null, '_controller' => 'App\\Controller\\ForumController::showForumPages'], ['slug', 'page'], null, null, false, true, null]],
        314 => [[['_route' => 'forum', '_controller' => 'App\\Controller\\ForumController::showForumPages'], [], null, null, false, false, null]],
        344 => [[['_route' => 'mod_show', 'slug' => null, '_controller' => 'App\\Controller\\InfileController::getPage'], ['slug'], null, null, false, true, null]],
        352 => [[['_route' => 'infile', '_controller' => 'App\\Controller\\InfileController::getPage'], [], null, null, false, false, null]],
        387 => [
            [['_route' => 'srm_show', 'slug' => null, '_controller' => 'App\\Controller\\SearchModController::search'], ['slug'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
