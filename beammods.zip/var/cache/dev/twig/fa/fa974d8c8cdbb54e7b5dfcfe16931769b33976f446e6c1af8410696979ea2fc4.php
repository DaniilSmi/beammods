<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* beam/index.html */
class __TwigTemplate_5951719f622ce1e8241bc910cd78be3aa1d4379cc1014376efb39fba2c503d5f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "beam/index.html"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "beam/index.html"));

        $this->parent = $this->loadTemplate("base.html", "beam/index.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "BEAMMODS";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "\t\t<div class=\"block1IndexPage\">
\t\t\t\t<div class=\"back\" style=\"background: url(/asset/img/index/";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["result"]) || array_key_exists("result", $context) ? $context["result"] : (function () { throw new RuntimeError('Variable "result" does not exist.', 7, $this->source); })()), "image", [], "any", false, false, false, 7), "html", null, true);
        echo ") no-repeat fixed; background-size: cover;\"></div>
\t\t\t\t<div class=\"mate\"></div>
\t\t\t\t<div class=\"otherInfo\">
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"textInfoOtherBl1\"><p>";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["result"]) || array_key_exists("result", $context) ? $context["result"] : (function () { throw new RuntimeError('Variable "result" does not exist.', 11, $this->source); })()), "text", [], "any", false, false, false, 11), "html", null, true);
        echo "</p></div>

\t\t\t\t\t\t<a href=\"/setup\"><button id=\"downloadGameIndex\">Установить</button></a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"block2IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"navoptions\">
\t\t\t\t\t<form>
\t\t\t\t\t<select class=\"select-css\">
\t\t\t\t\t\t<option value=\"dateNew\">Сортировать по:</option>
\t\t\t\t\t\t<option value=\"dateNew\">Дате(новые)</option>
\t\t\t\t\t\t<option value=\"dateOld\">Дате(старые)</option>
\t\t\t\t\t\t<option value=\"size\">Весу</option>
\t\t\t\t\t</select>
\t\t\t\t</form>
\t\t\t\t\t<div id=\"searchFormPg\">
\t\t\t\t\t\t<input type=\"text\" name=\"searchSite\" id=\"searchSite\" required=\"\" placeholder=\"Поиск по сайту\">
\t\t\t\t\t\t<button type=\"submit\" name=\"submitSearchSite\" id=\"submitSearchSite\"><img src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("asset/other/images/svg/justSearch.svg"), "html", null, true);
        echo "\"></button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"block3IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"contentBlock3IndexPage\">
\t\t\t\t<div class=\"forfor\"></div>
\t\t\t\t<div class=\"pagination\">
\t\t\t\t\t<!--<a href=\"#\" class=\"firstPagiHref\"><div id=\"pagiFirst\">1</div></a>
\t\t\t\t\t<a class=\"firstPagiHref2\"><div id=\"pagiTypical\">..</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">1</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\" class=\"currentPagiPage\">2</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">3</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">4</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">5</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">6</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">7</div></a>
\t\t\t\t\t<a class=\"firstPagiHref2\"><div id=\"pagiTypical\">..</div></a>
\t\t\t\t\t<a href=\"#\" class=\"firstPagiHref\"><div id=\"pagiEnd\">34</div></a>-->
\t\t\t\t\t45
\t\t\t\t\t
\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"ads\">
\t\t\t\t\t<div class=\"headerAds\">Реклама</div>
\t\t\t\t\t<div class=\"mostAds\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 65
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        echo "<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("asset/other/order.js"), "html", null, true);
        echo "\"></script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "beam/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 65,  121 => 30,  99 => 11,  92 => 7,  89 => 6,  79 => 5,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html' %}

{% block title  %}BEAMMODS{% endblock %}\t\t

{% block content %}
\t\t<div class=\"block1IndexPage\">
\t\t\t\t<div class=\"back\" style=\"background: url(/asset/img/index/{{result.image}}) no-repeat fixed; background-size: cover;\"></div>
\t\t\t\t<div class=\"mate\"></div>
\t\t\t\t<div class=\"otherInfo\">
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"textInfoOtherBl1\"><p>{{result.text}}</p></div>

\t\t\t\t\t\t<a href=\"/setup\"><button id=\"downloadGameIndex\">Установить</button></a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"block2IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"navoptions\">
\t\t\t\t\t<form>
\t\t\t\t\t<select class=\"select-css\">
\t\t\t\t\t\t<option value=\"dateNew\">Сортировать по:</option>
\t\t\t\t\t\t<option value=\"dateNew\">Дате(новые)</option>
\t\t\t\t\t\t<option value=\"dateOld\">Дате(старые)</option>
\t\t\t\t\t\t<option value=\"size\">Весу</option>
\t\t\t\t\t</select>
\t\t\t\t</form>
\t\t\t\t\t<div id=\"searchFormPg\">
\t\t\t\t\t\t<input type=\"text\" name=\"searchSite\" id=\"searchSite\" required=\"\" placeholder=\"Поиск по сайту\">
\t\t\t\t\t\t<button type=\"submit\" name=\"submitSearchSite\" id=\"submitSearchSite\"><img src=\"{{ asset('asset/other/images/svg/justSearch.svg') }}\"></button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"block3IndexPage\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"contentBlock3IndexPage\">
\t\t\t\t<div class=\"forfor\"></div>
\t\t\t\t<div class=\"pagination\">
\t\t\t\t\t<!--<a href=\"#\" class=\"firstPagiHref\"><div id=\"pagiFirst\">1</div></a>
\t\t\t\t\t<a class=\"firstPagiHref2\"><div id=\"pagiTypical\">..</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">1</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\" class=\"currentPagiPage\">2</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">3</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">4</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">5</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">6</div></a>
\t\t\t\t\t<a class=\"firstPagiHref\" href=\"#\"><div id=\"pagiTypical\">7</div></a>
\t\t\t\t\t<a class=\"firstPagiHref2\"><div id=\"pagiTypical\">..</div></a>
\t\t\t\t\t<a href=\"#\" class=\"firstPagiHref\"><div id=\"pagiEnd\">34</div></a>-->
\t\t\t\t\t45
\t\t\t\t\t
\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"ads\">
\t\t\t\t\t<div class=\"headerAds\">Реклама</div>
\t\t\t\t\t<div class=\"mostAds\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

{% endblock %}

{% block javascript %}<script type=\"text/javascript\" src=\"{{ asset('asset/other/order.js') }}\"></script>{% endblock %}", "beam/index.html", "/home/danilkaschoolnikprogrammist/php/beammods.ru/templates/beam/index.html");
    }
}
